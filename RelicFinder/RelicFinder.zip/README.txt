============================================================
             PALWORLD RELICFINDER MOD (v1.0)
============================================================

This client-side mod displays floating 3D text overlays with live 
distance tracking directly above Lifmunk Effigies (relics) and 
unopened Treasure Chests.

Features:
- Relics display a Cyan text marker: "Relic [Xm]"
- Chests display a Gold text marker: "Chest [Xm]"
- Distance counters update in real-time as you move.
- markers automatically hide within 2 meters to prevent close-range crashes.
- Hotkey: Press ALT + F8 to toggle the overlay markers on/off.
- Fully optimized and 100% lag-free.

------------------------------------------------------------
INSTALLATION INSTRUCTIONS
------------------------------------------------------------

1. Locate your Palworld game installation folder.
   (e.g., C:\Program Files (x86)\Steam\steamapps\common\Palworld)

2. Go to the UE4SS Mods folder:
   Palworld\Pal\Binaries\Win64\Mods
   (Note: If you are using the NativeMods setup, this folder might be located under Palworld\Mods\NativeMods\UE4SS\Mods)

3. Extract the "RelicFinder" folder from this zip file directly into the Mods folder.
   You should see:
   ...\Mods\RelicFinder\Scripts\main.lua

4. Open the "mods.txt" file located inside the Mods folder:
   ...\Mods\mods.txt

5. Add the following line at the bottom of mods.txt to enable the mod:
   RelicFinder : 1

6. (Optional) If your UE4SS version uses "mods.json" instead, open:
   ...\Mods\mods.json
   and add this entry before the closing bracket:
   ,
   {
       "mod_name": "RelicFinder",
       "mod_enabled": true
   }

7. Launch the game, load into your world, and enjoy!

------------------------------------------------------------
CONTROLS & CONFIGURATION
------------------------------------------------------------
- Alt + F8: Toggle the display of markers.
- To customize settings (such as colors, text size, or maximum distance), 
  open "RelicFinder/Scripts/main.lua" in any text editor and edit the CONFIG table.
============================================================
