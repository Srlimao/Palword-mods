============================================================
             PALWORLD LUA MODS BUNDLE (v1.0)
============================================================

This package contains two client-side Lua mods for Palworld, fully 
optimized, 100% lag-free, and crash-safe:

1. EnemyUI: Customizes Enemy HP display. Shows all HP bars around 
   you (up to 150m), even through walls and obstacles.
   - Hotkey: Press ALT + F9 to toggle HP bars.

2. RelicFinder: Displays floating 3D text overlays with live 
   distance tracking above Lifmunk Effigies and unopened Treasure Chests.
   - Relics display a Cyan marker: "Relic [Xm]"
   - Chests display a Gold marker: "Chest [Xm]"
   - Hotkey: Press ALT + F8 to toggle markers.

------------------------------------------------------------
INSTALLATION INSTRUCTIONS (Manual)
------------------------------------------------------------
1. Extract the "Mods" folder in this zip file directly into your game's
   Binaries directory:
   \Palworld\Pal\Binaries\Win64\

   (This will merge the files into your existing UE4SS folder structure at 
   \Binaries\Win64\Mods\NativeMods\UE4SS\Mods\)

2. Open the "mods.txt" file in your UE4SS Mods directory:
   \Binaries\Win64\Mods\NativeMods\UE4SS\Mods\mods.txt

3. Add the following lines to the bottom of the file to enable the mods:
   EnemyUI : 1
   RelicFinder : 1

4. (Optional) If your setup uses "mods.json", add these entries to:
   \Binaries\Win64\Mods\NativeMods\UE4SS\Mods\mods.json

   {
       "mod_name": "EnemyUI",
       "mod_enabled": true
   },
   {
       "mod_name": "RelicFinder",
       "mod_enabled": true
   }

5. Start the game, load into your world, and enjoy!

------------------------------------------------------------
CONFIGURATION
------------------------------------------------------------
You can customize settings (like distance range, colors, text scale, 
or update intervals) by opening the main.lua file of either mod in a 
standard text editor and modifying the CONFIG table at the top of the file:
- EnemyUI Config: RelicFinder/Mods/EnemyUI/Scripts/main.lua
- RelicFinder Config: RelicFinder/Mods/RelicFinder/Scripts/main.lua
============================================================
